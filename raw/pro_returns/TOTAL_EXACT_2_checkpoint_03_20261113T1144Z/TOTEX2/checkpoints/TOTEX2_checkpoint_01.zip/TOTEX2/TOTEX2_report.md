INCOMPLETE

| Item | State | Statements | Exact scope |
|---|---|---|---|
| A.1 | Open | A.1, A.2 | No universal proof or separator. |
| A.2: Q | Open | A.3, A.2 | Coefficient implication not decided. |
| A.2: every F_p | Open | A.3, A.2 | With Q, equivalent to the integral question. |
| B.1: triples | Open | B.1, B.5 | First undecided ordinary family size. |
| B.2: Leads 1-5 | Proved / corrected | B.3, B.4, B.5, B.6, B.9 | Formal claims proved; explanatory overstatements corrected. |
| C.1: AKR H_2 | Open | C.1, C.5 | Nonexactness is proved; infinite-stage survival/totality is not. |
| C.2: Leads 6-9 | Proved / refuted as worded | C.14, C.2, C.6, C.15, C.16 | Corrected claims proved; literal nonmonic-circle and any-ring assertions refuted. |
| D.1: both right-hand inclusions | Open | D.1, D.2 | Strict composite inclusion does not locate the intermediate class. |
| D.2: manuscript corrections | Proved within stated scope | D.3, D.4, D.5 | Known corrections audited; an exactness replacement still depends on A.1. |
| D.3: literature record | Recorded | Access table | Opened passages and failed body retrievals are individually listed. |
| Lead 1 | Proved | B.3 | Canonical isomorphism and both derivations. |
| Lead 2 | Proved | B.4 | One-relator criterion and Tor formula. |
| Lead 3 | Proved | B.5 | All small categories, including k=0. |
| Lead 4 | Proved; final gloss qualified | B.6, B.7 | Exactness is not siftedness or injectivity of the set-to-abelian comparison. |
| Lead 5(i) | Proved | B.9 | Membership and vanishing of the colimit class of kappa. |
| Lead 5(ii) | Proved in stronger form | B.8 | Common successors suffice. |
| Lead 5(iii) | Proved | B.9 | Affine annihilation gives a triple equalizer; joint annihilation still needed. |
| Lead 5(iv) | Proved | B.9, B.10 | Kernel, Tor quotient and mixed-cycle interpretation. |
| Lead 6 | Proved | C.13, C.14 | Finite-poset and sphere-face tests with explicit factorization. |
| Lead 7 | Proved conditionally; literal circle claim refuted | C.2, C.3, C.6 | The dimension consequence retains its hypothesis. |
| Lead 8 | Proved for nonzero rings; literal any-ring claim refuted | C.15 | Ty^op fails I, IV and totality; zero ring exceptional. |
| Lead 9(a) | Proved | C.16 | No reverse arrow q to p. |
| Lead 9(b) | Proved | C.16 | Unbounded hom-sets out of p. |
| Lead 9(c) | Proved | C.16 | Full cosieve remains a separator with the same minimal family size. |
| Lead 9(d) | Proved | C.16 | Ordinary postcomposites remain pairwise distinct. |

# TOTEX2 research record

AI-produced by GPT-6 Astra (OpenAI, ChatGPT Pro mode). No priority is claimed.

This is an incomplete research record. It does not satisfy the request to decide every item. No proof or counterexample is claimed for the main implication, for its triple case, or for the asserted all-stage survival in the repaired AKR category. This status is a mathematical limitation of the arguments recorded here; it is not attributed to an environmental interruption.

## Precisely what remains undecided

For a nonempty connected small category A, assume every component of every covariant category of elements El_A(H) is weakly contractible. The missing assertion is that for every finite ordinary parallel family a_0,...,a_k:p→q there exist r and t in Z[A(q,r)] with aug(t)=1 and ta_i=ta_0 for all i. The least family size not settled is three arrows. Pairwise affine equalization is already established, but iterating it produces affine pairs and does not formally handle larger ordinary families.

The column presentation Q_a=coker(P_q→P_p^k) gives exactly T_1(Q_a)=Z/ε(∩K_i). Totality supplies acyclicity of the row presentation and its row kernel. No argument here transfers that acyclicity to the column cokernel or its intersection kernel.

The coefficient questions remain undecided individually. The proved fieldwise-detection theorem shows that integral exactness, for any small category, is equivalent to rational exactness together with exactness over every prime field. This reduces the combined question; it does not decide either constituent.

For repaired AKR, the unresolved assertion is nonzero H_2 of the binary-quotient category of elements in the infinite union, uniformly for every admissible choice of construction parameters. Finite-stage persistence, pointwise free diagrams, geometric image intersections, and all-ring nonexactness do not establish this infinite-stage homology assertion.

## Principal established deductions

1. **Algebraic leads.** Leads 1–3 and the formal assertions of Leads 4–5 are proved with typed maps and exact sequences. Lead 1's former surjection is an isomorphism, both derivations are supplied, and the sign relating their explicit maps is recorded. Lead 2 works under I without an unnecessary connectedness hypothesis. Lead 3 covers every small category, including k=0. The normal form in Lead 5(ii) needs only common successors.
2. **The row/column distinction.** The row cokernel is a permutation module. The column cokernel presents the simultaneous equalizer obstruction. Neither a transposition of matrices nor the separate acyclicity of K_i identifies the two.
3. **The resolving-class proposal.** Universal direct membership of Q_a in the class proposed in P1 is false. A fully specified filtered category with four objects and seventeen arrows has Q_a(x)=Z²⊕Z/3. Every member of the proposed class is objectwise torsion free. This refutes direct membership even under filteredness. It leaves open finding a different module with the same T_1.
4. **A Ramsey criterion.** The morphism Ramsey property, with common successors, forces integral exactness. The proof extends a circle-valued character of the image of the column map, then discretizes its potentials into (3k+1)^k colors. It detects integral divisibility, not merely rational nonexistence. With arbitrary hom-sets the finite-pattern version suffices.
5. **Ordered graphs.** The category of finite linearly ordered simple graphs and increasing induced embeddings is exact, hence total. The required Ramsey theorem is Hubička–Nešetřil (2019), Corollary 4.3, inspected in the full primary text with its induced-embedding convention. This eliminates that candidate for all finite parallel families, not only the configurations computed.
6. **Compact inverse limits.** For a nonempty category with common successors, the finite-pattern morphism Ramsey condition is equivalent to nonempty strict limits of all contravariant diagrams of nonempty compact Hausdorff spaces. The proof includes finite witness sets and a simultaneous Ramsey tower. It remains unknown in this work whether totality implies this stronger property. Quasi-filteredness suffices for diagrams of nonempty finite sets whose sizes have one uniform bound.
7. **Finite tests and links.** Lead 6 is proved through the actual comprehensive factorization and finite-poset representatives of sphere maps. Lead 7's comparison theorem is proved by identifying its comma categories, with an explicit relative nerve complex for the homology conclusion. Its contractibility hypothesis fails for exceptional AKR pairs.
8. **The type category.** The variance description of Ty is proved from cuts in interval types. For Ty^op the specified pair has no commuting square and no affine equalizer over any nonzero ring. More strongly, an explicitly specified quotient action has H_1=Z.
9. **Minimal separators.** All four parts of Lead 9 are proved: the missing reverse arrow, unbounded hom-sets, reduction to the full cosieve of p, and pairwise distinct postcomposites.
10. **AKR coefficients.** The full C.2 induction was read. Its private-incidence consequence proves injectivity of the initial triple column map with coefficients in every abelian group, hence nonexistence of affine equalizers over every nonzero commutative ring. This is independent of totality of the union.
11. **Protected AKR cycles.** A complete weighted extension of the source induction gives a monomorphism P_{P_+}⊕P_{P_-}→K for the two first-stage binary filling cycles. Its cokernel is objectwise free and has split-injective transition maps. The argument covers every admissible stage, mixed protected source types, identity comparisons, and sum targets. It leaves the exact obstruction im(T_1(M)→Z²), including whether this image contains (1,−1).
12. **Split injections do not settle survival.** On the same quasi-filtered AKR category, the triple-column cokernel Q has finite free values and split-injective transitions with free cokernels, but T_1(Q)=Z. It is even the abelianization of a functor of finitely generated free groups whose arrows are free-factor inclusions. The proof uses relative private-generator elimination. These assertions concern quasi-filteredness and do not establish totality of AKR.
13. **Positive averaging fails under quasi-filteredness.** Every probability combination of the initial AKR W-arrows has total discrepancy of its second and third marginals from its first at least one. A layer-cake calculation turns the private-incidence expansion into this uniform bound. Finite-dimensional convex separation then supplies a contravariant diagram of nonempty compact convex polytopes with empty strict limit. Thus quasi-filteredness alone cannot provide the proposed compatible bounded potentials.
14. **Fixing coefficients in an element category can lose relations.** In Δ_inj, free Boolean algebras on the variables of an ordinal form an injective diagram. Two designated generators agree in the original set colimit, but the pairs (x_0,x_0) and (x_0,x_1) remain in different components of the relevant element construction. The natural valuation setting the distinguished generator to one and every other generator to zero separates the desired classes even after abelian colimit. This refutes that proposed shortcut under exactness and totality themselves.

## Corrections and qualifications

### The Leads

- **Lead 4.** The two affine-equalization statements are true. Its final phrase cannot be read as identifying exactness with siftedness or with injectivity of the set-to-abelian colimit comparison. In the exact category Δ_inj, the vectors 2[a]−[b] and [a] have the same abelian-colimit class but distinct set-colimit classes: increasing injections preserve the nonzero coefficient pattern. The cospan category on two point objects has three components, distinguished by <, =, >.
- **Lead 5.** The phrase “carried around a 1-cycle of A” must refer to a bar chain with module coefficients. BA itself is contractible under totality. The precise assertion proved is that κ cannot die using only the binary cycle subfunctor if the triple has no affine equalizer. There is no ordinary H_1(BA) obstruction.
- **Lead 6.** “Factors through” is a strict factorization via the explicitly defined natural map H_u→H. The finite-sphere assertion uses subdivision and simplicial approximation, rather than treating a continuous sphere map as an arbitrary functor without justification.
- **Lead 7.** The cone dimension consequence retains the comma-contractibility hypothesis. Equalizing precomposition gives an embedded cycle, but without monomorphisms its component need not literally be a circle. A finite three-object, eight-arrow category yields a component with fifteen vertices, twenty edges, and H_1=Z^6. In AKR all maps are monic, so the cited exceptional component is a circle.
- **Lead 8.** “Over any ring” needs “over any nonzero unital commutative ring.” Over the zero ring the zero combination has augmentation 1=0 and is an affine equalizer. The intrinsic failure of totality and integral exactness is unchanged.
- **Leads 1–3 and 9.** No false mathematical assertion was found within the stated hypotheses. The proof of Lead 2 explicitly retains aug(z)=0 in its Tor formula. Lead 3 handles the vacuous family k=0.

### R1–R11 and the supplied reviews

We read the relied-on proofs at the supplied locations; the following paragraphs identify the steps used rather than treating the earlier records as authority.

**R1.** Inheritance is the actual functor a↦coproduct over h of the fibres of an action on El_A(H); its element category is isomorphic to the iterated element category. Cyclic-subgroup covers then turn integral acyclicity into simple connectivity, and Hurewicz gives weak contractibility. The bar complex for Z[H] is literally the nerve complex. These facts justify permutation-module acyclicity and do not justify arbitrary-module acyclicity.

**R2.** The 1973 Theorem 1 and Lemma 1, and the 1976 Theorem 3.1 and Proposition 3.3, use augmentation-one integral combinations. An affine cocone gives the same abelian colimit because x−(Σn_if_i)x=Σn_i(x−f_ix). The finite-support reduction equalizes ordinary arrows in the union of supports of two affine arrows. The general commutative-ring statement is already the 1976 remark on page 296, correcting the earlier return's missing credit.

**R3.** We inspected the supplied interpolation proof: the coordinate change z_i−z_{i+1} is integral and invertible; compatible coordinate restrictions extend by inclusion–exclusion; gap monomials translate coface composition into y_iD_i; the simplicial identities handle all smaller injections. This supplies the needed unbounded proof of the ordinal example independently of the still unobtained 1974 body. The colored-word final-image exclusions are not used to settle a new claim here and are not promoted to newly verified results.

**R4.** The double-cosieve action forces common successors; applying it inside p/A forces I. The binary row presentation gives ε(K)=Z, and common successors turn its finite sum into one affine equalizer. For connected actions the zigzag is reduced to a cospan using I, then IV equalizes its two arrows affinely. These are the actual steps used in Leads 4 and 9.

**R5.** We read the minimal-period proof and the actual 1976 source. The invariant finite signed measure has support a union of finite periodic orbits. The least-period argument is what converts augmentation one into an ordinary fixed point. Corollary 4.3 handles reverse arrows, Corollary 4.4 weakly terminal objects, and Proposition 4.5 bounded representables. No finite category or monoid was searched as a separator.

**R6.** The sifted criterion is the connected cospan category, checked against Gabriel–Ulmer §§15.2(c), 15.9. A common successor of (q;u,id) and (q;v,id) gives one actual equalizer. For the Eilenberg–MacLane test, the degree-(n+1) spectral-sequence calculation first proves exactness, and the degree-2n cross summand then proves the tensor comparison and siftedness. For n=1 the exterior-square edge map is surjective using common successors. The universal-cover classification uses the specified action Hom_{ΠA}(a,−), the direct sum over its fibres, and the bar-model covering comparison. The earlier PRETOT F.3 and F.6 credits are retained.

**R7.** Both short exact sequences of the row presentation were recalculated. Their connecting morphisms give the two augmentations, not the intersection kernel. Leads 1 and 3 give the exact obstruction quotients, and Lead 5 now uses the expert's κ explicitly. We did not identify K⊂P_q² with K_1∩K_2.

**R8.** Stable formulations and the animated-abelian reflection remain reformulations. A free abelian resolution has terms free on underlying sets, but its structure maps can send basis vectors to sums. Totality cannot be applied as though every such map were a map of permutation bases. The fieldwise theorem in this record uses equal bar complexes after restriction of scalars, not an unjustified flat base-change claim.

**R9.** Only inherited element-category totality and the full-cosieve restriction are needed in the new separator reductions. For a full cosieve, extending a set-valued action by the empty set gives exactly the same element category. Any equalizer of a family out of p still lands in that cosieve, proving preservation of the particular nonexactness witness. We did not use the other closure operations to create a separator.

**R10.** The repaired B.5/B.6 formulas and the prior finite computations were read. We then inspected the entire C.2 induction through pages 385–389, including both (c_m) and (d_m), the least-cardinality block and two-sided sweep. The index set printed as {1,...,n} in the definition of L on page 387 must be {1,...,r}. The known expansion invariant gives the stronger all-coefficient private-incidence result. None of this is a survival proof for H_2 in the union.

**R11.** All listed credit and scope corrections are retained: the 1974 proof is distinct from the 1973 announcement; PRETOT F.6 is credited; adjoining a terminal object does not answer the nontrivial completion problem; triples do not formally imply arbitrary finite families; and κ is now used. Gabriel–Ulmer and Isbell 1968 were newly obtained in this run. Oberst and Isbell 1974 remain unobtained.

### Manuscript readings

At II ms. 36, y\X is required for finality of f:X→Y. The printed y\Y always has initial object id_y. At XII ms. 88, H' is a presheaf on U', so the displayed element category is U'/H'. The quoted conjecture at II ms. 36ter is refuted by Δ_inj. Siftedness alone does not imply totality: Δ^op and the simplicial circle supply a counterexample with the correct variance. Totality plus siftedness, or plus one fixed positive Eilenberg–MacLane truncation test, does imply filteredness. We did not independently collate the supplied transcription against the authoritative edition.

## Approaches tried, exact stopping points, and next mathematical steps

| Route | What was established or tested | Exact obstruction / next step |
|---|---|---|
| P1: resolving closure | Every member is objectwise torsion free; a filtered finite example gives Q_a(x)=Z²⊕Z/3. | Direct membership is false. A different module with the same T_1 would require a new construction that does not assume the desired vanishing. |
| P2: one relation | T_1(P_p/P_rz)=Z/ε(ann z); a Cayley-graph cycle module surjects onto the relation kernel. | A lift of z=2c_0−c_1−c_2 uses nonzero translates of edges. It is not a natural lift on which ann(z) acts trivially. A translation-invariant finite-support section already fails for two generators mapping to one copy of Z. |
| P3: κ and normal forms | κ dies in colim K; a zero-class normal form exists under common successors; a one-term form is annihilated by IV. | A finite sum of parallel differences has not been converted to one affine annihilator. Jointly equalizing the involved pairs is itself the missing simultaneous problem. |
| P4: dual potentials | Objectwise dual certificates and the integral circle-character separation are valid. | Objectwise nonempty solution spaces do not give a compatible inverse-limit point. Totality has not been shown to force the compact/Ramsey condition. |
| P5: stabilization | The spectral and animated-abelian identifications were inspected. | Strict colimits of sets and abelian colimits differ. Homotopy invariance of set colimits does not show the abelian reflection preserves the needed monomorphisms. |
| Model-category route | Totality gives homotopy invariance of ordinary simplicial-set colimits; I gives preservation of set monomorphisms. | Stabilization does not identify this functor with ordinary abelian colimit on the heart. A cofibrant replacement introduces the unresolved derived colimit. |
| Free/cotriple resolution | Its free terms are permutation modules. | Some face maps send a basis element to a linear combination, so it is not the linearization of a simplicial set diagram. |
| Tensor and iterated elements | Products and iterated element actions produce further acyclic permutation modules. | The required coefficientwise kernel intersection is not a product of set actions; tensoring does not identify it with the row kernel. |
| C1: dimension-one link comparison | The conditional comparison is proved; an exceptional AKR equalizing precomposition produces a cycle in the comma link. | The blanket dimension-one argument fails its hypothesis precisely at exceptional pairs. Need control of their link H_2 or of its image in old H_2. |
| C1: right-division closure | Tested explicitly; it fails already for identity-copy targets. | No unqualified factorization-through-image argument is valid. The failed invariant is not used as a proof. |
| C1: fixed subsets and intersections | Extensive exact tests on selected finite substages found connected fixed/intersection pieces. | An induction for every admissible attachment is missing. Pairwise overlap information alone can leave theta-type cycle relations. |
| C1: geodesic convexity | Selected finite image components pass exhaustive graph-distance tests. A complete generic repaired graph gluing yields a 26-cycle from two target edges. | Convex image components and bounded point-level paths do not suffice to preserve component injections. The example is not shown to occur in C.1; a stronger component-level invariant is needed there. |
| C1: marked cycle modules | The full weighted routing/counting induction and relative free-edge collapse are proved for all admissible stages. | The remaining term is im(T_1(M)→Z²). The AKR column module refutes the inference from finite free values and split-injective transitions to T_1=0, even with free-group lifts. |
| Compact convex averaging | A uniform positive-discrepancy estimate and finite-dimensional separation give nonempty polytopes with empty inverse limit over AKR. | Quasi-filteredness does not supply a compatible point. A totality-specific argument or additional structure of the particular functional diagram is required. |
| Boolean coefficient fixing | The proposed passage to an element component was tested on the exact total category Δ_inj. | It can destroy the original colimit relation; the explicit generator valuation separates the classes. |
| Signed marginals as actual points | Exact integer linear algebra for proper three-colorings of cycles C_3 through C_9 was performed. For C_5 an affine signed measure has every one-coordinate marginal concentrated at zero, although no constant coloring is proper. | Signed marginal identities cannot be used as positive support or existence statements. This is a finite warning about the proposed inference, not a categorical separator. |
| Quasi⇒total by dimension shifting | Algebraic dimension shifting lowers H_2 to T_1 of a kernel module. | That kernel need not be a permutation module. Loop/path models have space or groupoid fibres, not the discrete fibres required for an A-set. |
| C2: higher cone completion | Lead 6 identifies all finite sphere-filling tasks; private incidence protects nonexactness. | No general attachment has been constructed that fills an arbitrary task while preserving the invariant. |
| C3: literal and small B.9 variants | Prior literal attachments can kill H_2; exploratory smaller repaired B.9 tests were run. | The C.1 expansion parameter and invariant cannot be assumed for those variants. No all-stage separator follows. |
| C4: homogeneous candidates | A Ramsey theorem gives integral exactness; finite ordered graphs are ruled out completely. | Any remaining candidate must evade the proved Ramsey criterion. No new candidate with universal totality has been constructed. |
| C5: finite searches | Only finite pieces of infinite constructions, finite explicit counterexamples to auxiliary claims, and bounded combinatorial certificates were searched. | A finite or weakly terminal category cannot separate the main classes. No finite search is treated as a counterexample to A.1. |

## Computations and their scope

- **Finite torsion example:** all 52 composable pairs and 121 composable triples, identities and the terminal object are checked. The exact Smith diagonal is (1,1,1,3); the reduced determinant is 3 and a 3×3 minor is a unit. The exhibited order-three class has unique rational preimage (1,1,−1,−1)/3.
- **Nonmonic link example:** three objects, eight arrows, all seventeen composable pairs and thirty composable triples; the graph has fifteen vertices, twenty edges and first Betti number six.
- **Type category:** 961 word-pair descriptions, 2,731 composition checks, and 7,937 arrows from (+−+) into all 1,023 words of length at most nine. The general proof uses a target-independent functional; enumeration is a separate check.
- **Ordered graphs:** every ordered graph through six vertices was searched by exact rank over Q, F_2 and F_3. On six vertices there are 32,768 targets; vertex-triple equalizer counts are 42,34,42, and edge-pair counts are 8,0,8. The seven-vertex random sample has 20,000 graphs and seed 20261113 and is explicitly not exhaustive. The integral certificates on six and seven vertices are independently verified. The general Ramsey proof is independent of these counts.
- **AKR fixed-point graphs:** 11,628 selected-second-stage pairs and 131,868 critical-third-stage pairs with larger sources; 35,186 and 396,194 associated potential fixed subsets. These runs have no failures within their stated scope.
- **AKR intersections:** the critical target has 892 generating larger-source image sets and 1,189 distinct intersections of size at least two in their closure; no new higher-order sets beyond pairwise intersections arose in that finite run.
- **AKR convexity:** proper larger-source image sets were tested by all relevant breadth-first searches in selected second and third substages. The outputs identify each target and all counts. This is evidence for an invariant, not its proof.
- **AKR private incidence:** the critical third-stage target has 26,433 W-arrows. A complete private-vertex peeling certificate and its replay verifier prove the finite simultaneous-kernel assertion over every coefficient ring. The all-stage result instead relies on the audited source induction.
- **AKR protected cycles:** 594 protected cells at the critical target were checked; 528,066 relative cell removals were replayed across all 891 larger-source incoming arrows. The all-stage proof is the separate weighted induction, not this enumeration.
- **Generic repaired gluing:** the two-edge input and thirteen-copy gluing have exactly 26 vertices and 26 edges, forming a cycle and merging old graph components. This tests and refutes the stated generic preservation lemma only.
- **Signed colorings:** the exact lattice augmentation generator is three for C_3 and one for C_4 through C_9. The seven-term C_5 certificate is printed and verified by the program. It makes no claim about a total category.
- **Terminated explorations:** right-division searches that were stopped for cost retain their partial outputs and are identified as terminated. No conclusion about their unsearched range is drawn. The exploratory s=13 repaired B.9 search does not meet C.1's expansion parameters.

All mathematical programs and their outputs are retained under code/. The copied stage model is supplied prior code, not newly authored mathematics. Exact arithmetic, graph searches and finite category checks have distinct roles from the universal proofs.

## Reproducibility, package scope, and checkpoints

The paper uses LuaLaTeX and BibTeX with an author–year bibliography. The build driver records its exit status and scans the final log for undefined references/citations, duplicate labels and overfull boxes. In this workspace, a local Type 1 LaTeX format compensates for omitted runtime format/font-loader files; no system configuration is changed. A normal complete TeX Live installation uses ordinary LuaLaTeX. This build detail is not a reason for the mathematical incompleteness.

Source PDFs fetched from publishers and author sites are research inputs and are not redistributed in the ZIP. Their URLs and inspected locations are recorded. User-supplied stage code and bibliography metadata needed to reproduce the computations are included. The package excludes temporary TeX format files, Python caches and intermediate page renderings; authored source, final paper, report, register, references, programs and outputs are retained.

The checkpoint is a record of established subparts and current gaps, not a completed Part A, B, C or D. No assertion that the environment forced an interruption is made. Later checkpoints use new filenames. If a later package supersedes a passage in a checkpoint, the report identifies the superseding statement or the error.


# Literature audit for D.3

AI-produced by GPT-6 Astra (OpenAI, ChatGPT Pro mode); no priority claim. This file records actual access, not conclusions inferred from search snippets. Search date: 13 November 2026.

## Requested records

| Source | Access in this run | Exact locations relevant to the task |
|---|---|---|
| Isbell–Mitchell (1973), *Exact colimits*, Bull. AMS79,994–996 | **Opened attached primary PDF; root's theorem audit completed** | Theorems1–3 and Lemma1 were checked. Theorem3 announces the ordinal-injection exact-colimit example; its independent polynomial proof is audited in the current paper. |
| Isbell–Mitchell (1976), *Exact colimits and fixed points*, Trans. AMS220,289–298 | Opened attached primary body and extracted local text | Theorem3.1 (exactness iff components of affine category filtered), Proposition3.3 (I+III), remark p.296 (commutative coefficient rings), Theorem4.1 and Corollaries4.2–4.4 (ordinary equalization exclusions), Proposition4.5 and Corollary4.6 (bounded representables); p.298 asks the fixed-point/exactness question. Root read all §§1–4. |
| Isbell (1968), *A note on exact colimits*, Canad. Math. Bull.11(4),569–572 | **Opened full primary PDF** from Cambridge | The unnumbered theorem in §1, pp.569–570, characterizes exactness by finite additive relations and common successors. The unnumbered theorem in §2, pp.571–572, proves exactness iff filteredness for a monoid. Do not invent theorem numbers; cite by section and page. |
| Isbell (1974), *Exact colimits. I*, Ann. Math.100(3),633–637 | **Not obtained**: Annals bibliographic page and JSTOR record opened; full-body requests failed | No theorem number or content claim assigned to unopened body. Tried exact-title searches, DOI10.2307/1970960, Annals official page, JSTOR stable record, and stable/pdf endpoint. |
| Oberst (1968), *Homology of categories and exactness of direct limits*, Math. Z.107,87–115 | **Not obtained**: publisher metadata opened; body requires subscription; direct content/PDF request failed | No original theorem number asserted. Tried exact title with author, year/volume/pages, DOI10.1007/BF01111023, searches for publicly indexed full text, publisher article and content/PDF endpoint. Husainov Theorem2.7 is opened as a secondary statement, but is not represented as opening Oberst. |
| Adámek–Reiterman (1975), *Fixed points in representations of categories*, Trans. AMS211,239–247 | **Not obtained in this run**: official AMS full PDF and article endpoints failed with403 or internal error | Searched exact title, DOI10.1090/S0002-9947-1975-0376799-X, AMS journal and shorter URL forms; publisher volume contents and bibliographic records are not counted as body access. No content claim assigned. |
| Adámek–Koubek–Reiterman (1981), *Embeddings into categories with fixed points in representations*, Czech. Math. J.31(3),368–389 | **Opened attached primary PDF; construction audit completed for the cited results** | A.4's correction, B.5–B.9, C.1, and the full induction of TheoremC.2 were checked. The finite-tests agent independently inspected (10),(11), C.1's numerical hypotheses, and every C.2 counting step on pp.385–389; the threshold-three weighted extension is detailed in `finite_marked_cycle_audit.md`. This is distinct from proving the still-unresolved infinite-stage H2 persistence. |
| Husainov (2002), *Homological dimension theory of small categories*, J. Math. Sci.110(1),2273–2321 | **Opened English full text in author-uploaded ResearchGate rendering**, plus author-hosted Russian translation | Theorem2.4 (flows modulo internal flows compute first derived colimit); Theorem2.5 (affinization criterion); Theorem2.6 (flatness of a permutation presheaf when all transition maps inject); Theorem2.7 (equivalent exactness formulations, attributed to Oberst); Problem2.5 (fixed-point-property/exactness question). Its Problem2.5 is not a source for the current totality question; in light of AKR1981 the weaker fixed-point equivalence is already false. |
| Gabriel–Ulmer (1971), *Lokal präsentierbare Kategorien*, LNM221 | **Opened full 181-page scan** from Doug Ravenel's university-hosted collection, downloaded locally | §5.2, printed pp.55–56: filteredness iff set colimits commute with finite limits (the alpha variant); §15.2(c), printed p.187: finite cocone zigzag criterion, reducible to two objects; §15.9, pp.190–191: Yoneda completion argument supplies its converse. These are the relevant classical sifted criterion locations. §14.10, pp.177–178, concerns Kan extension preserving specified limits under explicit colimit-commutation assumptions; it does not supply total=>exact. |
| Flatness of the one-element monoid act | **Opened primary Hemelaer–Rogers (2021)** and author manuscript by Valdis Laan | Hemelaer–Rogers Definition1.6 explicitly distinguishes monomorphism-flatness from finite-limit-flatness; Proposition1.8 equates latter with filtering flat functors; Theorem2.32 treats monomorphism preservation by connected components; Theorem2.49 characterizes finite-limit preservation for the one-element act by cofilteredness/right collapsibility, with the reverse variance from our covariant monoid actions. Laan, *On a generalization of strong flatness*, Proposition2.4 and the paragraph following Lemma2.6 distinguish (O) from strong flatness using the one-element act over a nontrivial group. |

## Exact source URLs and local availability

- Isbell1968: https://www.cambridge.org/core/services/aop-cambridge-core/content/view/344EA0110F34F24298FD42E14305F634/S0008439500056836a.pdf/a-note-on-exact-colimits.pdf . Opened web ref `turn6view0`, full§2 also `turn20view2`. Local fetched file: `TOTEX2/sources/Isbell1968.pdf`, HTTP200, 307030 bytes.
- Isbell1974 official record: https://annals.math.princeton.edu/1974/100-3/p05 ; JSTOR https://www.jstor.org/stable/1970960 . Not body access.
- Oberst1968: https://link.springer.com/article/10.1007/BF01111023 . Subscription preview only.
- Adámek–Reiterman1975 attempted official PDF: https://www.ams.org/journals/tran/1975-211-00/S0002-9947-1975-0376799-X/S0002-9947-1975-0376799-X.pdf ; shorter `/tran/...` endpoint also attempted.
- Husainov English author-uploaded text: https://www.researchgate.net/publication/232724279_Homological_dimension_theory_of_small_categories ; relevant complete passages opened (`turn13view2`, `turn13view3`). Russian author translation: https://husainov51.narod.ru/files/rep2rus.pdf . The author publications list identifies this as a Russian translation of the English article.
- Gabriel–Ulmer: https://www.sas.rochester.edu/mth/sites/doug-ravenel/otherpapers/Gabriel-Ulmer.pdf . Local `TOTEX2/sources/gabriel.pdf`, `TOTEX2/sources/GabrielUlmer1971.txt`. Opened web `turn3view0`.
- Hemelaer–Rogers2021: https://link.springer.com/article/10.1007/s10485-020-09620-y . Full publisher HTML opened (`turn17view0`; relevant proof `turn20view1`).
- Laan: https://kodu.ut.ee/~vlaan/condo.pdf . Opened full144-line PDF representation, locally fetched as `TOTEX2/sources/LaanStrongFlat.pdf`, HTTP200, 88952 bytes.
- Goerss–Jardine, *Simplicial Homotopy Theory* (2009reprint): https://www.sas.rochester.edu/mth/sites/doug-ravenel/otherpapers/Goerss-Jardine2.pdf . TheoremI.11.4, SectionIII.4, TheoremIII.4.8 opened to support finite-poset representatives. Local `TOTEX2/sources/GoerssJardine2009.pdf`, HTTP200, 2411067 bytes.

## Mathematical distinctions confirmed

1. The one-element monoid act being flat in the semigroup sense can mean only preservation of monomorphisms by its set tensor functor. It must not be confused with flatness of the constant right ZM-module. The paper's explicit terminology warning rules out that identification.
2. For the one-element act, finite-limit-flatness is precisely the appropriate filteredness condition after reversing variance. This gives no separator because it is already stronger than the totality under investigation.
3. Search hits using 'totally aspherical' often concern Grothendieck test-category terminology in which the diagonal is aspherical. That is a different definition from universal asphericity under ordinary final images in this prompt. No such hit is used as a result about the present class.
4. The type-map description in PRETOT is checked directly in the proof; there is no reliance on a variance-sensitive informal statement.

## Search record for the main question

Exact phrases and combinations queried on the web (two engines, with stronger coverage checks for missing primary sources):

- `totally aspherical exact colimits`
- `totalement asphérique exact`
- `homotopy flat acts category`
- `monoid one-element flat strongly flat trivial act`
- `exact colimits Ramsey`
- `exact colimits ordered graphs`
- `homotopy colimits Ramsey`
- exact titles/authors/DOIs of every requested unprovided source, including exclusions of aggregator domains when searching for primary copies

No opened source in this search proves or refutes the implication from universal contractibility of categories of elements to exactness of abelian colimits. This sentence reports the search result, not a claim that the problem is open in the mathematical literature.

## Follow-up: Ramsey and an additional primary record

- Hubička and Nešetřil, *All those Ramsey classes*, arXiv:1606.07979v4
  (3 September 2019), https://arxiv.org/pdf/1606.07979 , opened full text
  (`turn25view2`, `turn26view1`). The morphism definition at printed p.6
  preserves and reflects relations; Ramsey is defined at printed p.3.
  Corollary 4.3 at printed p.51 explicitly states the Ramsey property for
  finite simple graphs with arbitrary linear order. Theorem 3.21 is the
  broader relational-structure statement. The authored circle-character
  argument in `sections/ordered_graphs.tex` now proves Ramsey implies
  integral exactness (with common successors), so this candidate is exact.
  This exactness implication is our proved deduction, not a theorem
  attributed to the Ramsey source; no priority claim is made. Local source:
  `sources/HubickaNesetril2019.pdf`, fetched successfully with HTTP200.
- A renewed web open of the official Adámek–Reiterman1975 PDF still failed
  with internal error (`turn25view0`).
- Adámek and Reiterman (1976), *Exactness of the set-valued colim*,
  Comment. Math. Univ. Carol.17(1),97–103, found via DML-CZ and its PDF
  opened: https://dml.cz/bitstream/handle/10338.dmlcz/105677/CommentatMathUnivCarol_017-1976-1_8.pdf
  (`turn26view0`, full body `turn34view0`). Proposition I.2(a), pp.97--98,
  characterizes preservation of monomorphisms by Ore squares; I.2(b)
  characterizes equalizer preservation by filtered components; I.2(c)
  characterizes exact set colimits by filteredness (with the usual nonempty
  requirement, forced by preservation of the terminal set). Section II.3,
  p.100, repeats the false fixed-point/exact-Ab-colimit equivalence.
  More precisely, it identifies exact abelian colimits with agreement of
  pairs of endotransformations of each indecomposable set-valued functor,
  and equivalently with a fixed point for each single endotransformation.
  AKR1981 A.4, printed p.370, explicitly corrects the earlier 1975 remark:
  pairwise affine equalization (3*) was confused with simultaneous affine
  equalization for every finite tuple (3). Its counterexample also refutes
  the repeated 1976 II.3 assertion; A.4 does not explicitly cite II.3.
  II.3 must not be used as a valid theorem. The valid I.2 Set-colimit
  characterizations are separate from that false abelian assertion. This is not the
  requested 1975 paper and does not count as opening that paper. Local
  source: `sources/AdamekReiterman1976.pdf`, fetched with HTTP200.

Queries in this follow-up: `Nešetřil Rödl ordered graphs Ramsey theorem
induced embeddings partite construction pdf`; exact 1975 title with PDF.
Further C.1 metric-induction searches used `finite graph convex partial
isometry cyclic amalgamation extension`, `finite extension partial
isometry one partial isometry path cycles metric spaces`, and Solecki's
exact title *Extending partial isometries*. No retrieved theorem was
applied to the prescribed beta gluing; generic existence of an isometric
extension would not prove preservation in that specific construction.

## Execution notes

`code/finite_source_fetch.py`, `code/finite_source_fetch_additional.py`, and `code/finite_source_fetch_followup.py` preserve public download attempts and HTTP failures. An initial inline attempt to import the third-party `requests` module failed because it is unavailable; all actual fetches use Python's standard-library urllib. Source PDFs are research inputs, not new results; they should be omitted from the deliverable ZIP unless separate copyright permissions justify redistribution. The authored proofs and exact citations remain in the paper.
